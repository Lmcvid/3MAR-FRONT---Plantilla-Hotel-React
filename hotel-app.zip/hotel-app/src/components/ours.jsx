import React from 'react'

export default function Ours() {
  return (
    <div>
      Ours
    </div>
  )
}
