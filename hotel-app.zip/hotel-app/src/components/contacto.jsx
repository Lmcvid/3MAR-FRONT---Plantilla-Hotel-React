import React from 'react'

export default function Contacto() {
  return (
    <div>
      Contacto
    </div>
  )
}
