import React from 'react'

export default function Habitaciones() {
  return (
    <div>
      Habitaciones
    </div>
  )
}
